import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'rutinas.dart';

class ContinuousVoiceHandler with WidgetsBindingObserver {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final BuildContext context;
  final Map<String, WidgetBuilder> _commandRoutes;
  final String _notRecognizedMessage;
  final String _activationCommand;
  final Function(bool isEnabled)? onStatusChanged;
  Function(String)? _customCommandHandler;

  bool _isEnabled = false;
  bool _isProcessing = false;

  final List<String> _deactivationCommands = [
    'terminar',
    'gracias',
    'gracias asistente',
    'silencio',
  ];

  final List<String> _rutinas = ['marcha', 'piernas', 'equilibrio', 'avanzada'];
  final List<String> _rutinasAv = ['uno', 'dos', 'tres', 'cuatro'];

  ContinuousVoiceHandler({
    required this.context,
    required Map<String, WidgetBuilder> commandRoutes,
    String notRecognizedMessage = 'Perdón, no entendí.',
    String activationCommand = 'asistente',
    this.onStatusChanged,
  })  : _commandRoutes = commandRoutes,
        _notRecognizedMessage = notRecognizedMessage,
        _activationCommand = activationCommand.toLowerCase() {
    WidgetsBinding.instance.addObserver(this);
  }

  Future<void> initializeContinuousListening() async {
    final ok = await _speech.initialize(
      onStatus: _statusListener,
      onError: (error) {
        debugPrint('STT error: $error');
        _restartListening();
      },
    );
    if (!ok) {
      debugPrint('El reconocimiento de voz no está disponible.');
      return;
    }
    _startListening();
    _showListeningStatus();
  }

  void _startListening() {
    _speech.listen(
      onResult: (result) =>
          _processContinuousCommand(result.recognizedWords.toLowerCase()),
      listenFor: const Duration(hours: 1),
      pauseFor: const Duration(seconds: 3),
      partialResults: true,
      localeId: 'es-MX',
      listenMode: stt.ListenMode.confirmation,
    );
  }

  void _restartListening() async {
    if (_speech.isListening) await _speech.stop();
    await Future.delayed(const Duration(milliseconds: 300));
    _startListening();
  }

  void _statusListener(String status) {
    if (status == 'notListening') _restartListening();
  }

  void _processContinuousCommand(String command) async {
    if (_isProcessing) return;
    _isProcessing = true;
    command = command.trim().toLowerCase();
    debugPrint('‑ Escuchado: $command');

    if (!_isEnabled && command.contains(_activationCommand)) {
      _isEnabled = true;
      onStatusChanged?.call(_isEnabled);
      _showFeedback('Asistente activado. Di un comando.');
      _isProcessing = false;
      _restartListening();
      return;
    } else if (_isEnabled && _deactivationCommands.any(command.contains)) {
      _isEnabled = false;
      onStatusChanged?.call(_isEnabled);
      _showFeedback('Asistente desactivado.');
      _isProcessing = false;
      _restartListening();
      return;
    }

    bool matched = false;

    for (final key in _commandRoutes.keys) {
      if (command.contains(key.toLowerCase())) {
        _navigateToScreen(key);
        matched = true;
        break;
      }
    }

    for (int i = 0; i < _rutinas.length && !matched; i++) {
      if (command.contains(_rutinas[i])) {
        matched = true;
        Future.delayed(
            const Duration(milliseconds: 300),
                () => Rutinas.ejecutarRutina(context, i));
        debugPrint('‑‑> Rutina $i vía voz');
        break;
      }
    }

    for (int i = 0; i < _rutinasAv.length && !matched; i++) {
      if (command.contains(_rutinasAv[i])) {
        matched = true;
        Future.delayed(
            const Duration(milliseconds: 300),
                () => Rutinas.ejecutarRutinaAvanzada(context, i));
        debugPrint('‑‑> Rutina avanzada $i vía voz');
        break;
      }
    }

    if (!matched && command.contains('desconectar')) {
      Rutinas.navegarDesconectar(context);
      matched = true;
    }

    if (!matched && command.contains('regresa')) {
      Navigator.of(context).maybePop();
      _showFeedback('Regresando a la pantalla anterior...');
      matched = true;
    }

    if (!matched && _customCommandHandler != null) {
      _customCommandHandler!(command);
      matched = true;
    }

    if (!matched) {
      //_showFeedback(_notRecognizedMessage);
    }

    _isProcessing = false;
    _restartListening();
  }

  void _navigateToScreen(String cmd) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: _commandRoutes[cmd]!),
    );
  }

  void _showFeedback(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  void _showListeningStatus() {
    _showFeedback('Escuchando… Di “$_activationCommand” para activar.');
  }

  void stopListening() {
    _speech.stop();
    _isEnabled = false;
    onStatusChanged?.call(_isEnabled);
  }

  bool isListening() => _speech.isListening;

  void setCustomCommandHandler(Function(String) handler) {
    _customCommandHandler = handler;
    _restartListening();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !_speech.isListening) {
      _restartListening();
    } else if (state == AppLifecycleState.paused) {
      _speech.stop();
    }
  }

  void dispose() {
    stopListening();
    WidgetsBinding.instance.removeObserver(this);
  }
}
