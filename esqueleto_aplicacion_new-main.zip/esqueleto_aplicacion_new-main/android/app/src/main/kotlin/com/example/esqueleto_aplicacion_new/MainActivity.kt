package com.example.esqueleto_aplicacion_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
